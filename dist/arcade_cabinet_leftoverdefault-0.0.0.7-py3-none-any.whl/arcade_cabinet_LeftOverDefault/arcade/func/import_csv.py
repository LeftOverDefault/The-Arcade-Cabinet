from arcade_cabinet_LeftOverDefault.arcade.utils.imports import *

def import_csv(path) -> list:
    layout = []

    with open(file=path, mode="r") as world_map:
        pass
        # layout = reader(world_map, delimiter=",")
        # for row in layout:
            # layout.append(list(row))
    
    return layout